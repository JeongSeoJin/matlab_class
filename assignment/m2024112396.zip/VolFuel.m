% Homework 5 정서진(2024112396)

function V = VolFuel(y)
    R = 24;
    V = pi.*((-1/3).*y.^3 + R^2.*y);
end